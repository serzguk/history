// Устанавливаем начальное время в секундах (1 час, 59 минут, 0 секунд)
let timeInSeconds = 1 * 60 * 60 + 59 * 60;

// Функция для обновления таймера
function updateTimer() {
  const hours = Math.floor(timeInSeconds / 3600);
  const minutes = Math.floor((timeInSeconds % 3600) / 60);
  const seconds = timeInSeconds % 60;

  // Выводим время на страницу
  const timerElement = document.getElementById('countdown'); // замени 'timer' на ID элемента, где должен отображаться таймер
  timerElement.innerHTML = `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  // Уменьшаем время на 1 секунду
  timeInSeconds--;

  // Если время истекло (дошло до 0), начинаем отсчет заново
  if (timeInSeconds < 0) {
    timeInSeconds = 1 * 60 * 60 + 59 * 60; // Устанавливаем начальное время заново
  }
}

// Обновляем таймер каждую секунду
const interval2 = setInterval(updateTimer, 1000);

// Вызываем функцию для обновления таймера сразу после загрузки страницы
updateTimer();








const floatingButton = document.querySelector('.floating-button');
const section3 = document.querySelector('.section2');

window.addEventListener('scroll', () => {
  const section3Top = section3.getBoundingClientRect().top;
  const windowHeight = window.innerHeight;

  if (section3Top <= windowHeight * 0.5) {
    floatingButton.classList.add('active');
  } else {
    floatingButton.classList.remove('active');
  }
});

floatingButton.addEventListener('click', () => {
  // Вставьте здесь код, который должен выполниться при клике на кнопку
  // Например: alert('Button clicked!');
});



// const floatingButton2 = document.querySelector('.floating-button');
// const footer = document.querySelector('.section7');


// window.addEventListener('scroll', () => {
//   const footerTop = footer.getBoundingClientRect().top;
//   const windowHeight = window.innerHeight;

//   if (footerTop <= windowHeight) {
//     floatingButton2.classList.remove('active');
//   } else {
//     floatingButton2.classList.add('active');
//   }
// });

const floatingButton2 = document.querySelector('.floating-button');
const footer = document.querySelector('.footer');
const section1 = document.querySelector('.section3');

window.addEventListener('scroll', () => {
  const footerTop = footer.getBoundingClientRect().top;
  const section1Top = section1.getBoundingClientRect().top;
  const windowHeight = window.innerHeight;

  if (footerTop <= windowHeight || section1Top > windowHeight) {
    floatingButton2.classList.remove('active');
  } else {
    floatingButton2.classList.add('active');
  }
});



