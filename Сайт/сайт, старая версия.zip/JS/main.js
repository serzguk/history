
// Отправка формы 

$(document).ready(function(){
	$('[data-submit]').on('click', function(e){
	    e.preventDefault();
		$(this).parents('form').submit();
	})
	$.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        var re = new RegExp(regexp);
        return this.optional(element) || re.test(value);
    },
    "Please check your input."
  );
	function valEl(el){
      el.validate({
      rules:{
        tel:{
          required:true,
          regex: '^([\+]+)*[0-9\x20\x28\x29\-]{5,20}$'
        },
        email:{
          required:true,
          regex: '[A-Za-zА-Яа-яЁё]'
        },
      },
      messages:{
        tel:{
            required:'Заповніть поле будь ласка',
            regex:'Телефон може містити символи + - ()'
        },
        email:{
            required:'Заповніть поле будь ласка',
            regex:'Імя може містити лише літери'
        },
      },            
      submitHandler: function (form) {
        $('#loader').fadeIn();
        var $form = $(form);
        var $formId = $(form).attr('id');
        switch($formId){
          case'goToNewPage':
            $.ajax({
                type: 'POST',
                url: $form.attr('action'),
                data: $form.serialize(),
              }).always(function (response) {  
              // редирект
              location.href='https://secure.wayforpay.com/button/b9e287d5e4bf9';
          });
        break;                 
      }       
      return false; 
        }                           
      })
      }                        
     
      $('.js-form').each(function() {
        valEl($(this)); 
      });          
   })

